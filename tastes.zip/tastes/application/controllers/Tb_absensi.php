<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tb_absensi extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Tb_absensi_model');
        $this->load->library('form_validation');
    }

    public function index()
    {
        $q = urldecode($this->input->get('q', TRUE));
        $start = intval($this->input->get('start'));
        
        if ($q <> '') {
            $config['base_url'] = base_url() . 'tb_absensi/index.html?q=' . urlencode($q);
            $config['first_url'] = base_url() . 'tb_absensi/index.html?q=' . urlencode($q);
        } else {
            $config['base_url'] = base_url() . 'tb_absensi/index.html';
            $config['first_url'] = base_url() . 'tb_absensi/index.html';
        }

        $config['per_page'] = 10;
        $config['page_query_string'] = TRUE;
        $config['total_rows'] = $this->Tb_absensi_model->total_rows($q);
        $tb_absensi = $this->Tb_absensi_model->get_limit_data($config['per_page'], $start, $q);
        $config['full_tag_open'] = '<ul class="pagination pagination-sm no-margin pull-right">';
        $config['full_tag_close'] = '</ul>';
        $this->load->library('pagination');
        $this->pagination->initialize($config);

        $data = array(
            'tb_absensi_data' => $tb_absensi,
            'q' => $q,
            'pagination' => $this->pagination->create_links(),
            'total_rows' => $config['total_rows'],
            'start' => $start,
        );
        $this->template->load('template','tb_absensi/tb_absensi_list', $data);
    }

    public function read($id) 
    {
        $row = $this->Tb_absensi_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_absensi' => $row->id_absensi,
		'nip' => $row->nip,
		'nama_lengkap' => $row->nama_lengkap,
		'tanggal_mulai' => $row->tanggal_mulai,
		'tanggal_selesai' => $row->tanggal_selesai,
		'jenis_keterangan' => $row->jenis_keterangan,
		'sub_jenis_keterangan' => $row->sub_jenis_keterangan,
		'nomor_surat' => $row->nomor_surat,
		'keterangan' => $row->keterangan,
		'tanggal_sekarang' => $row->tanggal_sekarang,
	    );
            $this->template->load('template','tb_absensi/tb_absensi_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_absensi'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('tb_absensi/create_action'),
	    'id_absensi' => set_value('id_absensi'),
	    'nip' => set_value('nip'),
	    'nama_lengkap' => set_value('nama_lengkap'),
	    'tanggal_mulai' => set_value('tanggal_mulai'),
	    'tanggal_selesai' => set_value('tanggal_selesai'),
	    'jenis_keterangan' => set_value('jenis_keterangan'),
	    'sub_jenis_keterangan' => set_value('sub_jenis_keterangan'),
	    'nomor_surat' => set_value('nomor_surat'),
	    'keterangan' => set_value('keterangan'),
	    'tanggal_sekarang' => set_value('tanggal_sekarang'),
	);
        $this->template->load('template','tb_absensi/tb_absensi_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nip' => $this->input->post('nip',TRUE),
		'nama_lengkap' => $this->input->post('nama_lengkap',TRUE),
		'tanggal_mulai' => $this->input->post('tanggal_mulai',TRUE),
		'tanggal_selesai' => $this->input->post('tanggal_selesai',TRUE),
		'jenis_keterangan' => $this->input->post('jenis_keterangan',TRUE),
		'sub_jenis_keterangan' => $this->input->post('sub_jenis_keterangan',TRUE),
		'nomor_surat' => $this->input->post('nomor_surat',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
		'tanggal_sekarang' => $this->input->post('tanggal_sekarang',TRUE),
	    );

            $this->Tb_absensi_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('tb_absensi'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Tb_absensi_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('tb_absensi/update_action'),
		'id_absensi' => set_value('id_absensi', $row->id_absensi),
		'nip' => set_value('nip', $row->nip),
		'nama_lengkap' => set_value('nama_lengkap', $row->nama_lengkap),
		'tanggal_mulai' => set_value('tanggal_mulai', $row->tanggal_mulai),
		'tanggal_selesai' => set_value('tanggal_selesai', $row->tanggal_selesai),
		'jenis_keterangan' => set_value('jenis_keterangan', $row->jenis_keterangan),
		'sub_jenis_keterangan' => set_value('sub_jenis_keterangan', $row->sub_jenis_keterangan),
		'nomor_surat' => set_value('nomor_surat', $row->nomor_surat),
		'keterangan' => set_value('keterangan', $row->keterangan),
		'tanggal_sekarang' => set_value('tanggal_sekarang', $row->tanggal_sekarang),
	    );
            $this->template->load('template','tb_absensi/tb_absensi_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_absensi'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_absensi', TRUE));
        } else {
            $data = array(
		'nip' => $this->input->post('nip',TRUE),
		'nama_lengkap' => $this->input->post('nama_lengkap',TRUE),
		'tanggal_mulai' => $this->input->post('tanggal_mulai',TRUE),
		'tanggal_selesai' => $this->input->post('tanggal_selesai',TRUE),
		'jenis_keterangan' => $this->input->post('jenis_keterangan',TRUE),
		'sub_jenis_keterangan' => $this->input->post('sub_jenis_keterangan',TRUE),
		'nomor_surat' => $this->input->post('nomor_surat',TRUE),
		'keterangan' => $this->input->post('keterangan',TRUE),
		'tanggal_sekarang' => $this->input->post('tanggal_sekarang',TRUE),
	    );

            $this->Tb_absensi_model->update($this->input->post('id_absensi', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('tb_absensi'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Tb_absensi_model->get_by_id($id);

        if ($row) {
            $this->Tb_absensi_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('tb_absensi'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('tb_absensi'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nip', 'nip', 'trim|required');
	$this->form_validation->set_rules('nama_lengkap', 'nama lengkap', 'trim|required');
	$this->form_validation->set_rules('tanggal_mulai', 'tanggal mulai', 'trim|required');
	$this->form_validation->set_rules('tanggal_selesai', 'tanggal selesai', 'trim|required');
	$this->form_validation->set_rules('jenis_keterangan', 'jenis keterangan', 'trim|required');
	$this->form_validation->set_rules('sub_jenis_keterangan', 'sub jenis keterangan', 'trim|required');
	$this->form_validation->set_rules('nomor_surat', 'nomor surat', 'trim|required');
	$this->form_validation->set_rules('keterangan', 'keterangan', 'trim|required');
	$this->form_validation->set_rules('tanggal_sekarang', 'tanggal sekarang', 'trim|required');

	$this->form_validation->set_rules('id_absensi', 'id_absensi', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "tb_absensi.xls";
        $judul = "tb_absensi";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nip");
	xlsWriteLabel($tablehead, $kolomhead++, "Nama Lengkap");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal Mulai");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal Selesai");
	xlsWriteLabel($tablehead, $kolomhead++, "Jenis Keterangan");
	xlsWriteLabel($tablehead, $kolomhead++, "Sub Jenis Keterangan");
	xlsWriteLabel($tablehead, $kolomhead++, "Nomor Surat");
	xlsWriteLabel($tablehead, $kolomhead++, "Keterangan");
	xlsWriteLabel($tablehead, $kolomhead++, "Tanggal Sekarang");

	foreach ($this->Tb_absensi_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nip);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nama_lengkap);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal_mulai);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal_selesai);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jenis_keterangan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->sub_jenis_keterangan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nomor_surat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->keterangan);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tanggal_sekarang);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=tb_absensi.doc");

        $data = array(
            'tb_absensi_data' => $this->Tb_absensi_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('tb_absensi/tb_absensi_doc',$data);
    }

}

/* End of file Tb_absensi.php */
/* Location: ./application/controllers/Tb_absensi.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-04-01 04:55:00 */
/* http://harviacode.com */