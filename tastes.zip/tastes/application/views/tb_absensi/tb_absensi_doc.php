<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Tb_absensi List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nip</th>
		<th>Nama Lengkap</th>
		<th>Tanggal Mulai</th>
		<th>Tanggal Selesai</th>
		<th>Jenis Keterangan</th>
		<th>Sub Jenis Keterangan</th>
		<th>Nomor Surat</th>
		<th>Keterangan</th>
		<th>Tanggal Sekarang</th>
		
            </tr><?php
            foreach ($tb_absensi_data as $tb_absensi)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $tb_absensi->nip ?></td>
		      <td><?php echo $tb_absensi->nama_lengkap ?></td>
		      <td><?php echo $tb_absensi->tanggal_mulai ?></td>
		      <td><?php echo $tb_absensi->tanggal_selesai ?></td>
		      <td><?php echo $tb_absensi->jenis_keterangan ?></td>
		      <td><?php echo $tb_absensi->sub_jenis_keterangan ?></td>
		      <td><?php echo $tb_absensi->nomor_surat ?></td>
		      <td><?php echo $tb_absensi->keterangan ?></td>
		      <td><?php echo $tb_absensi->tanggal_sekarang ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>