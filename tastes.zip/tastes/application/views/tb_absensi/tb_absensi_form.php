<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA TB_ABSENSI</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nip <?php echo form_error('nip') ?></td><td><input type="text" class="form-control" name="nip" id="nip" placeholder="Nip" value="<?php echo $nip; ?>" /></td></tr>
	    <tr><td width='200'>Nama Lengkap <?php echo form_error('nama_lengkap') ?></td><td><input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" placeholder="Nama Lengkap" value="<?php echo $nama_lengkap; ?>" /></td></tr>
	    <tr><td width='200'>Tanggal Mulai <?php echo form_error('tanggal_mulai') ?></td><td><input type="date" class="form-control" name="tanggal_mulai" id="tanggal_mulai" placeholder="Tanggal Mulai" value="<?php echo $tanggal_mulai; ?>" /></td></tr>
	    <tr><td width='200'>Tanggal Selesai <?php echo form_error('tanggal_selesai') ?></td><td><input type="date" class="form-control" name="tanggal_selesai" id="tanggal_selesai" placeholder="Tanggal Selesai" value="<?php echo $tanggal_selesai; ?>" /></td></tr>
	    <tr><td width='200'>Jenis Keterangan <?php echo form_error('jenis_keterangan') ?></td><td><input type="text" class="form-control" name="jenis_keterangan" id="jenis_keterangan" placeholder="Jenis Keterangan" value="<?php echo $jenis_keterangan; ?>" /></td></tr>
	    <tr><td width='200'>Sub Jenis Keterangan <?php echo form_error('sub_jenis_keterangan') ?></td><td><input type="text" class="form-control" name="sub_jenis_keterangan" id="sub_jenis_keterangan" placeholder="Sub Jenis Keterangan" value="<?php echo $sub_jenis_keterangan; ?>" /></td></tr>
	    <tr><td width='200'>Nomor Surat <?php echo form_error('nomor_surat') ?></td><td><input type="text" class="form-control" name="nomor_surat" id="nomor_surat" placeholder="Nomor Surat" value="<?php echo $nomor_surat; ?>" /></td></tr>
	    
        <tr><td width='200'>Keterangan <?php echo form_error('keterangan') ?></td><td> <textarea class="form-control" rows="3" name="keterangan" id="keterangan" placeholder="Keterangan"><?php echo $keterangan; ?></textarea></td></tr>
	    <tr><td width='200'>Tanggal Sekarang <?php echo form_error('tanggal_sekarang') ?></td><td><input type="date" class="form-control" name="tanggal_sekarang" id="tanggal_sekarang" placeholder="Tanggal Sekarang" value="<?php echo $tanggal_sekarang; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_absensi" value="<?php echo $id_absensi; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('tb_absensi') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>